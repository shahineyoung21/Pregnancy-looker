package com.mybrother.medical.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Colors = lightColorScheme(
    primary = Color(0xFF3D6B5A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD7E9DF),
    onPrimaryContainer = Color(0xFF10251D),
    background = Color(0xFFF7F8FC),
    surface = Color.White,
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFFFFDAD6)
)

@Composable
fun MyBrotherTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
