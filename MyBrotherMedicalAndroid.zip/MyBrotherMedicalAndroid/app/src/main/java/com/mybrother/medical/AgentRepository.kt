package com.mybrother.medical

import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

object AgentRepository {
    private val api: AgentApi by lazy {
        val base = BuildConfig.SUPER_AGENT_URL.trimEnd('/') + "/"
        Retrofit.Builder()
            .baseUrl(base)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(AgentApi::class.java)
    }

    suspend fun ask(message: String): AskResponse = api.ask(AskRequest(message))
}
