package com.mybrother.medical

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mybrother.medical.ui.theme.MyBrotherTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyBrotherTheme { AppScreen() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@androidx.compose.runtime.Composable
fun AppScreen() {
    var question by remember { mutableStateOf("") }
    var answer by remember {
        mutableStateOf("اسألني عن معلومة صحية، دواء، غذاء، أو معنى نتيجة طبية. سأعرض المصادر الموثوقة المستخدمة مع الإجابة.")
    }
    var sources by remember { mutableStateOf<List<SourceItem>>(emptyList()) }
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("My Brother Medical", fontWeight = FontWeight.Bold)
                        Text("مساعد صحي قائم على الأدلة", style = MaterialTheme.typography.labelSmall)
                    }
                },
                navigationIcon = {
                    Icon(Icons.Default.HealthAndSafety, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                }
            )
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(pad).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(Modifier.height(4.dp))
                Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.HealthAndSafety, null, modifier = Modifier.size(48.dp))
                        Spacer(Modifier.size(14.dp))
                        Column {
                            Text("المعلومة أولاً، والمصدر دائماً", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text("لا يستبدل الطبيب، ولا يغيّر الجرعات أو الأدوية من تلقاء نفسه.", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = question,
                    onValueChange = { question = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("اكتب سؤالك الطبي") },
                    trailingIcon = {
                        IconButton(onClick = {
                            if (question.isNotBlank()) {
                                answer = "جاري تجهيز إجابة موثقة من الوكيل الطبي…"
                                scope.launch {
                                    runCatching { AgentRepository.ask(question) }
                                        .onSuccess { response ->
                                            answer = response.answer
                                            sources = response.sources
                                        }
                                        .onFailure { error ->
                                            answer = "تعذر الاتصال بالسوبر وكيل الآن. تأكد من إعداد عنوان الخدمة ثم حاول مرة أخرى."
                                        }
                                }
                            }
                        }) {
                            Icon(Icons.Default.Send, contentDescription = "إرسال")
                        }
                    }
                )
            }

            item {
                Card(shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("إجابة الوكيل", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(answer)
                        Spacer(Modifier.height(12.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("المصادر الموثقة", fontWeight = FontWeight.SemiBold)
                        if (sources.isEmpty()) {
                            Text("ستظهر المصادر هنا بعد اتصال التطبيق بالسوبر وكيل.", style = MaterialTheme.typography.bodySmall)
                        } else {
                            sources.forEach { source ->
                                Text("• ${source.publisher}: ${source.title}", style = MaterialTheme.typography.bodySmall)
                                Text(source.url, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            item {
                FeatureCard("💊 مواعيد الأدوية", "تنبيهات محلية ومعلومات الاستعمال المرتبطة بالمصدر الطبي.", Icons.Default.Medication, R.drawable.ic_pill_clock)
            }

            item {
                FeatureCard("🥗 التغذية", "بطاقات توضيحية عن العناصر الغذائية ومتى تكون النصيحة مرتبطة بالحالة.", Icons.Default.MenuBook, R.drawable.ic_food)
            }

            item {
                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("🚨 تنبيه السلامة", fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("أعراض الطوارئ أو الأعراض الشديدة تحتاج إلى تقييم طبي مباشر، وليس الاعتماد على التطبيق وحده.")
                    }
                }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun FeatureCard(title: String, body: String, icon: androidx.compose.ui.graphics.vector.ImageVector, imageRes: Int) {
    Card(shape = RoundedCornerShape(20.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(imageRes), contentDescription = null, modifier = Modifier.size(64.dp))
            Spacer(Modifier.size(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.size(6.dp))
                    Text(title, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(5.dp))
                Text(body, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
