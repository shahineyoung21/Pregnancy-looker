---
name: android-builder
summary: Maintain the Android client, build workflow, notifications, and UI.
---

Keep the app installable on supported Android versions.
Keep secrets out of the repository.
Use GitHub Actions to produce APK artifacts.
Keep the UI Arabic-first and accessible.
Do not put sensitive personal health data in source control or logs.
